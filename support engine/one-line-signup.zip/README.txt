A Pen created at CodePen.io. You can find this one at https://codepen.io/vineethtr/pen/ZBpebQ.

 single line signup model 